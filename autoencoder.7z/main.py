import numpy as np
from Autoencoders import Autoencoder
from sklearn import datasets


if __name__ == '__main__':
    hidden_dim = 1
    data = datasets.load_iris().data
    input_dim = len(data[0])
    ae = Autoencoder(input_dim, hidden_dim)
    ae.train(data)
    ae.test(np.array([[8, 4, 6, 2]]).reshape(-1, 4))



