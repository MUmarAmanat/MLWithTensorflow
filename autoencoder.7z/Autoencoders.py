"""
Author: Muhammad Umar Amanat
Discription: Class for autoencoder, which can also use for building
             stacked autoencoder
Requirements: Not any data dependency
"""
import tensorflow as tf
import numpy as np
tf.compat.v1.disable_v2_behavior()


class Autoencoder:
    def __init__(self, input_dim, hidden_dim, epochs=250, learning_rate=0.001):
        self.epoch = epochs
        self.learning_rate = learning_rate
        x = tf.compat.v1.placeholder(dtype=tf.float32, shape=[None, input_dim], name='x')
        # in order to refrain from name conflicts in tensorflow
        with tf.compat.v1.name_scope('encode'):
            weights = tf.compat.v1.Variable(tf.compat.v1.random_normal([input_dim, hidden_dim]), name='encode_weights')
            biases = tf.compat.v1.Variable(tf.zeros(shape=[hidden_dim]), dtype=tf.compat.v1.float32,
                                           name='encode_biases')
            encoded = tf.compat.v1.nn.tanh(tf.add(tf.compat.v1.matmul(x, weights, name='encode_dot'), biases,
                                                  name='encode_add'),
                                 name='encode_tanh')

        with tf.compat.v1.name_scope('decode'):
            weights = tf.compat.v1.Variable(tf.compat.v1.random.uniform(shape=[hidden_dim, input_dim],
                                                                        name='decode_weights_uniform'),
                                  dtype=tf.compat.v1.float32, name='decode_weights')
            biases = tf.compat.v1.Variable(tf.zeros([input_dim]), name='decode_biases')
            decoded = tf.compat.v1.add(tf.compat.v1.matmul(encoded, weights, name='deocde_matmul'), biases,
                                       name='decode_add')

        self.x = x
        self.encode = encoded
        self.decode = decoded
        self.loss = tf.compat.v1.sqrt(tf.compat.v1.reduce_mean(tf.compat.v1.square(tf.compat.v1.subtract(x,
                                                                                                         self.decode))))
        self.train_op = tf.compat.v1.train.RMSPropOptimizer(self.learning_rate).minimize(self.loss)
        self.saver = tf.compat.v1.train.Saver()

    def train(self, data):
        num_samples = len(data)
        with tf.compat.v1.Session() as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            for i in range(self.epoch):
                for j in range(num_samples):
                    l, _ = sess.run([self.loss, self.train_op], feed_dict={self.x: [data[j]]})
                if i % 10 == 0:
                    print('epoch {0}: loss = {1}'.format(i, l))
                    self.saver.save(sess, './model.ckpt')
            self.saver.save(sess, './model.ckpt')


    def test(self, data):
         with tf.compat.v1.Session() as sess:
            self.saver.restore(sess, './model.ckpt')
            hidden, reconstructed = sess.run([self.encode, self.decode], feed_dict={self.x: data})
            print('input data ', data)
            print('compressed data', hidden)
            print('reconstructed data', reconstructed)
            return reconstructed

















